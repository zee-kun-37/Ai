# AI Editing Studio + Android APK

## APK banana (GitHub) - ab server / Termux ki zaroorat NAHI
Repo ke root mein ye sab files upload karo, phir Actions > Build APK > Run workflow.
Artifact "ai-studio-apk" download karke unzip karo, app-debug.apk install karo.

FFmpeg ab APK ke andar hi chalta hai (ffmpeg.wasm). Workflow build ke waqt ffmpeg files
`app/www/local/ffmpeg/` mein khud daal deta hai - internet sirf AI keys (Cohere/Groq/Gemini) ke liye chahiye,
ffmpeg editing offline chalti hai.

Notes:
- Editing phone ke CPU par single-thread chalti hai, isliye bade/HD videos slow honge (compress/resize/merge).
  Chhoti clips, trim, audio, GIF, frame - fast.
- Files app ke andar (IndexedDB) rehti hain. Output save karne ke liye "download" dabao -> share sheet khulti hai.
- Subtitles burn: Latin (English/Roman Urdu) text ke liye Roboto font bundled hai.

## Purana tareeqa (optional): PC / Termux server
`studio/` folder abhi bhi Node + system ffmpeg ke saath chal sakta hai (`./termux-start.sh`).
