# AI Editing Studio + Android APK

## 1) APK banana (GitHub)
Repo ke root mein ye sab files upload karo, phir Actions > Build APK > Run workflow.
Artifact "ai-studio-apk" download karke unzip karo, app-debug.apk install karo.

## 2) Phone par server chalana (Termux, zaroori)
APK sirf ek window hai. Server Termux mein chalna chahiye:

    pkg update && pkg install -y nodejs ffmpeg unzip
    termux-setup-storage
    cd ~/storage/downloads && unzip -o <repo-zip-name>.zip
    cd <repo-folder> && chmod +x termux-start.sh && ./termux-start.sh

Phir APK kholo. Termux band mat karo (battery: Unrestricted).
