#!/data/data/com.termux/files/usr/bin/bash
# Run inside Termux: ./termux-start.sh
termux-wake-lock 2>/dev/null
cd "$(dirname "$0")/studio" && npm start
