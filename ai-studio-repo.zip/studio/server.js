'use strict';
// AI Editing Studio - local server. Zero dependencies. Needs Node 18+ and ffmpeg/ffprobe on PATH.
const http = require('http'), fs = require('fs'), path = require('path');
const K = require('./lib/core'), { chat } = require('./lib/ai'), { TOOLS } = require('./lib/tools');
const J = require('./lib/jobs');

const PORT = +process.env.PORT || 3000;
const MAX_UPLOAD = (+process.env.MAX_UPLOAD_MB || 2048) * 1048576;
const PUB = path.join(__dirname, 'public');
const STATIC = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css' };

const json = (res, code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
const readBody = (req, limit = 5e6) => new Promise((ok, no) => {
  const b = []; let n = 0;
  req.on('data', d => { n += d.length; if (n > limit) { no(new Error('Body too large')); req.destroy(); } else b.push(d); });
  req.on('end', () => ok(Buffer.concat(b))); req.on('error', no);
});
const readJson = async req => { try { return JSON.parse((await readBody(req)).toString() || '{}'); } catch { throw new Error('Bad JSON'); } };

// Streams the upload straight to disk (no RAM buffering) with a size limit.
function upload(req, res, name) {
  const id = K.newId(), safe = K.safeName(name), p = path.join(K.FILES, id + '-' + safe), ws = fs.createWriteStream(p);
  let n = 0, dead = false;
  const kill = () => { dead = true; req.unpipe(ws); ws.destroy(); fs.unlink(p, () => {}); };
  req.on('data', d => { n += d.length; if (n > MAX_UPLOAD && !dead) { kill(); json(res, 413, { error: 'File too large (limit ' + MAX_UPLOAD / 1048576 + ' MB)' }); req.resume(); } });
  req.on('aborted', () => { if (!dead) kill(); });
  ws.on('finish', () => { if (!dead) { K.register(id, safe, p, null); json(res, 200, { id, name: safe, size: n }); } });
  ws.on('error', e => { if (!dead) { dead = true; json(res, 500, { error: e.message }); } });
  req.pipe(ws);
}

// Downloads and inline playback, with HTTP Range support so video seeking works.
function serveFile(req, res, f, inline) {
  const size = fs.statSync(f.path).size, type = K.mimeOf(f.name);
  const show = inline && /^(video|audio|image|text\/plain)/.test(type);
  const h = { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'X-Content-Type-Options': 'nosniff',
    'Content-Disposition': (show ? 'inline' : 'attachment') + `; filename="${f.name}"` };
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  if (m && (m[1] || m[2])) {
    const s = m[1] ? +m[1] : size - +m[2], e = m[1] && m[2] ? Math.min(+m[2], size - 1) : size - 1;
    if (s > e || s >= size) { res.writeHead(416, { 'Content-Range': 'bytes */' + size }); return res.end(); }
    res.writeHead(206, { ...h, 'Content-Range': `bytes ${s}-${e}/${size}`, 'Content-Length': e - s + 1 });
    return fs.createReadStream(f.path, { start: s, end: e }).pipe(res);
  }
  res.writeHead(200, { ...h, 'Content-Length': size });
  fs.createReadStream(f.path).pipe(res);
}

// Streams a background job's events as NDJSON. Closing the browser only detaches the
// stream — the job keeps running server-side and notifies on completion (lib/jobs.js).
function streamJob(res, handle) {
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson', 'Cache-Control': 'no-cache' });
  const send = o => {
    if (res.writableEnded || res.destroyed) return;
    res.write(JSON.stringify(o) + '\n');
    if (o.t === 'done' || o.t === 'error') { handle.listeners.delete(send); res.end(); } // final event closes the stream; the job itself may live on
  };
  handle.listeners.add(send);
  res.on('close', () => handle.listeners.delete(send)); // browser closed: detach, job keeps running
}

// Visual trimmer assets: waveform PNG and 12-frame filmstrip JPG (cached on disk).
async function wavePic(req, res, f, film) {
  try {
    const out = film
      ? await J.cachedWave(f.id, '-film.jpg', async p => {
          const info = await K.probe(f.path);
          const n = 12, fps = (n / Math.max(1, info.duration)).toFixed(4);
          await K.execP('ffmpeg', ['-y', '-i', f.path, '-vf', `fps=${fps},scale=128:-2,tile=${n}x1`, '-frames:v', '1', p]);
        })
      : await J.cachedWave(f.id, '.png', p => K.execP('ffmpeg', ['-y', '-i', f.path, '-filter_complex', 'showwavespic=s=1200x96:colors=#7c6cff|#22d3ee', '-frames:v', '1', p]));
    res.writeHead(200, { 'Content-Type': film ? 'image/jpeg' : 'image/png', 'Cache-Control': 'no-cache' });
    fs.createReadStream(out).pipe(res);
  } catch (e) { return json(res, 400, { error: K.redact(e.message) }); }
}

const TEST_URLS = {
  cohere: k => ['https://api.cohere.com/v1/models', { Authorization: 'Bearer ' + k }],
  groq: k => ['https://api.groq.com/openai/v1/models', { Authorization: 'Bearer ' + k }],
  gemini: k => ['https://generativelanguage.googleapis.com/v1beta/models', { 'x-goog-api-key': k }],
  github: k => ['https://api.github.com/user', { Authorization: 'Bearer ' + k, 'User-Agent': 'studio' }],
};
let health = { ffmpeg: false, ffprobe: false };
Promise.all(['ffmpeg', 'ffprobe'].map(b => K.execP(b, ['-version']).then(() => true, () => false)))
  .then(([a, b]) => { health = { ffmpeg: a, ffprobe: b }; if (!a || !b) console.warn('WARNING: ffmpeg/ffprobe not found on PATH. Install FFmpeg.'); });

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://x'), P = u.pathname;
    if (req.headers.host && !/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(req.headers.host)) return json(res, 403, { error: 'forbidden' }); // DNS-rebinding guard
    if (req.headers.origin) { let ok = false; try { ok = new URL(req.headers.origin).host === req.headers.host; } catch {} if (!ok) return json(res, 403, { error: 'bad origin' }); } // CSRF guard
    const M = req.method;

    if (P === '/api/health') return json(res, 200, health);
    if (P === '/api/settings' && M === 'GET') { const s = K.loadSettings(); return json(res, 200, Object.fromEntries(K.PROVIDERS.map(k => [k, !!s[k]]))); }
    if (P === '/api/settings' && M === 'POST') {
      const j = await readJson(req), s = K.loadSettings();
      for (const k of K.PROVIDERS) if (k in j) { if (j[k]) s[k] = String(j[k]).trim(); else delete s[k]; }
      K.saveSettings(s); return json(res, 200, { ok: true });
    }
    if (P === '/api/test') {
      const p = u.searchParams.get('p'), k = K.loadSettings()[p];
      if (!TEST_URLS[p] || !k) return json(res, 200, { ok: false, msg: 'No key saved' });
      const [url, headers] = TEST_URLS[p](k);
      try { const r = await fetch(url, { headers }); return json(res, 200, { ok: r.ok, msg: r.ok ? 'Connected' : 'Rejected (' + r.status + ')' }); }
      catch { return json(res, 200, { ok: false, msg: 'Network error' }); }
    }
    if (P === '/api/upload' && M === 'POST') return upload(req, res, u.searchParams.get('name') || 'file');
    if (P === '/api/files' && M === 'GET') return json(res, 200, K.listFiles());
    if (P.startsWith('/api/file/')) {
      const id = P.split('/')[3];
      if (M === 'DELETE') return json(res, 200, { ok: K.removeFile(id) });
      let f; try { f = K.need(id); } catch { return json(res, 404, { error: 'not found' }); }
      return serveFile(req, res, f, u.searchParams.get('inline') === '1');
    }
    if (P.startsWith('/api/text/')) {
      let f; try { f = K.need(P.split('/')[3]); } catch { return json(res, 404, { error: 'not found' }); }
      if (!/^text\/plain/.test(K.mimeOf(f.name)) || fs.statSync(f.path).size > 2e6) return json(res, 400, { error: 'Not an editable text file' });
      return json(res, 200, { name: f.name, text: fs.readFileSync(f.path, 'utf8') });
    }
    if (P === '/api/savetext' && M === 'POST') { // saving an edit creates a NEW version; the original stays untouched
      const j = await readJson(req), o = K.outPath(j.name || 'edited.txt', j.parent);
      fs.writeFileSync(o.p, String(j.text || '')); return json(res, 200, K.finish(o));
    }
    if (P === '/api/tool' && M === 'POST') { // manual editor / tool panel: run one tool as a background job
      const j = await readJson(req);
      if (!TOOLS[j.name]) return json(res, 400, { error: 'Unknown tool' });
      const label = String(j.label || j.name).slice(0, 60);
      const h = J.runJob('tool', label, { name: j.name, chat_id: j.chat_id || null },
        async c => { const r = await TOOLS[j.name].run(j.args || {}, c); return { result: r.result }; });
      return streamJob(res, h);
    }
    if (P === '/api/chat' && M === 'POST') { // AI chat runs as a background job too
      const j = await readJson(req);
      const label = String(j.label || 'AI request').slice(0, 60);
      const h = J.runJob('chat', label, { chat_id: j.chat_id || null }, c => chat(j.messages || [], c));
      return streamJob(res, h);
    }
    if (P === '/api/jobs' && M === 'GET') return json(res, 200, { jobs: J.listJobs() }); // queue drawer + background sync
    if (P.startsWith('/api/jobs/') && M === 'POST') { // /api/jobs/:id/stop
      const parts = P.split('/');
      if (parts[4] === 'stop') return json(res, 200, { ok: J.stopJob(parts[3]) });
      return json(res, 404, { error: 'not found' });
    }
    if ((P.startsWith('/api/wave/') || P.startsWith('/api/wave-film/')) && M === 'GET') {
      let f; try { f = K.need(P.split('/')[3]); } catch { return json(res, 404, { error: 'not found' }); }
      return wavePic(req, res, f, P.startsWith('/api/wave-film/'));
    }

    const fp = path.join(PUB, P === '/' ? 'index.html' : P);
    if (!fp.startsWith(PUB + path.sep) || !fs.existsSync(fp) || fs.statSync(fp).isDirectory()) return json(res, 404, { error: 'not found' });
    res.writeHead(200, { 'Content-Type': STATIC[path.extname(fp)] || 'text/plain' }); fs.createReadStream(fp).pipe(res);
  } catch (e) { if (!res.headersSent) json(res, 500, { error: K.redact(e.message) }); else res.end(); }
}).listen(PORT, '127.0.0.1', () => {
  console.log('Studio running at http://localhost:' + PORT);
  console.log('Background jobs: close the tab anytime — finished jobs fire an OS notification (set NOTIFY=0 to disable).');
  const n = K.cleanup(); if (n) console.log('Cleaned ' + n + ' old files (older than ' + K.RETENTION_DAYS + ' days)');
  setInterval(K.cleanup, 3600e3).unref();
});
