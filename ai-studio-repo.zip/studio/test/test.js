'use strict';
const os = require('os'), fs = require('fs'), path = require('path');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-test-'));
const test = require('node:test'), assert = require('node:assert');
const { spawnSync } = require('child_process');
const K = require('../lib/core'), { TOOLS, toolDefs } = require('../lib/tools');

test('srtTime formats timestamps', () => { assert.equal(K.srtTime(3661.5), '01:01:01,500'); assert.equal(K.srtTime(0), '00:00:00,000'); });
test('atempoChain stays inside 0.5..2 per filter', () => {
  assert.equal(K.atempoChain(1.5), 'atempo=1.5000'); assert.equal(K.atempoChain(4), 'atempo=2,atempo=2.0000'); assert.equal(K.atempoChain(0.25), 'atempo=0.5,atempo=0.5000');
});
test('safeName strips paths and odd chars', () => { assert.equal(K.safeName('../../etc/pa$$wd.mp4'), 'pa__wd.mp4'); assert.equal(K.safeName(''), 'file'); });
test('num clamps and defaults', () => { assert.equal(K.num('abc', 5, 1, 9), 5); assert.equal(K.num(99, 5, 1, 9), 9); });
test('parseSilence + keepSegments', () => {
  const s = K.parseSilence('silence_start: 2\nsilence_end: 4.5 | silence_duration: 2.5\nsilence_start: 9', 10);
  assert.deepEqual(s, [{ s: 2, e: 4.5 }, { s: 9, e: 10 }]);
  const k = K.keepSegments(s, 10);
  assert.equal(k.length, 2); assert.ok(k[0][0] === 0 && k[0][1] > 2);
});
test('cropBox gives even centered 9:16 box', () => { const b = K.cropBox(1920, 1080, 9, 16); assert.deepEqual(b, { cw: 608, ch: 1080 }); });
test('mimeOf serves html as plain text', () => { assert.match(K.mimeOf('a.html'), /text\/plain/); assert.equal(K.mimeOf('x.mp4'), 'video/mp4'); });
test('toolDefs lists all tools with required params', () => {
  assert.ok(toolDefs.length >= 16);
  const t = toolDefs.find(x => x.function.name === 'trim_media'); assert.deepEqual(t.function.parameters.required, ['file_id', 'start', 'end']);
});

const hasFF = spawnSync('ffmpeg', ['-version']).status === 0;
test('integration: trim, speed, crop, silence, merge, gif, frame', { skip: !hasFF && 'ffmpeg missing' }, async () => {
  const src = path.join(K.FILES, 'aaaaaaaa-src.mp4');
  const r = spawnSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=15:duration=4', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=4', '-shortest', '-pix_fmt', 'yuv420p', src]);
  assert.equal(r.status, 0); K.register('aaaaaaaa', 'src.mp4', src, null);
  const c = { sig: undefined, out: [], emit() {} };
  const run = async (n, a) => (await TOOLS[n].run({ file_id: 'aaaaaaaa', ...a }, c)).result;
  const trimmed = await run('trim_media', { start: 1, end: 3 });
  assert.ok(Math.abs((await K.probe(K.need(trimmed.id).path)).duration - 2) < 0.3);
  assert.equal(K.need(trimmed.id).parent, 'aaaaaaaa'); // version lineage
  const sp = await run('change_speed', { speed: 2 }); assert.ok(Math.abs((await K.probe(K.need(sp.id).path)).duration - 2) < 0.3);
  const cr = await run('crop_video', { preset: 'vertical_9x16' }); const ci = await K.probe(K.need(cr.id).path); assert.equal(ci.w, 1080); assert.equal(ci.h, 1920);
  await run('remove_silence', {}); await run('make_gif', { start: 0, duration: 1 }); await run('extract_frame', { time: 1 });
  const mg = await run('merge_media', { file_ids: 'aaaaaaaa,' + trimmed.id }); assert.ok((await K.probe(K.need(mg.id).path)).duration > 3.5);
});
