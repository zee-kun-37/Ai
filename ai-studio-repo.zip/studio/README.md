# AI Editing Studio (local-first) v0.3

Requires Node 18+ and ffmpeg + ffprobe on PATH.

    npm start      # open http://localhost:3000
    npm test       # unit + ffmpeg integration tests

Open API Settings and paste keys: Cohere (required, AI brain), Groq (Whisper transcription), Gemini (video analysis).

## What's new in 0.3
- **Background jobs**: every chat and tool job runs server-side. Close the tab anytime —
  the job keeps running and you get an OS notification when it's done ("come and check").
  Jobs persist across server restarts (`data/jobs.json`); interrupted jobs are flagged.
  - Notifications: `notify-send` (Linux), `osascript` (macOS), toast balloon (Windows).
    Set `NOTIFY=0` to disable, or click the bell in the header for browser notifications.
  - `GET /api/jobs` (queue + re-attach results), `POST /api/jobs/:id/stop`
- **UI overhaul**: quick-start cards, collapsible tool panel with parameter forms,
  drag & drop + paste upload, toasts (no more alert()), first-run setup wizard,
  command palette (Ctrl/Cmd+K), markdown answers with copy button, auto-named chats,
  results grid view, inline chat rename, storage/ffmpeg/key status in the header,
  progress in the tab title, expandable tool steps with copyable args, mobile bottom sheets
- **Visual trimmer**: filmstrip thumbnails + waveform with draggable start/end handles,
  click-to-seek, presets (first 30s / last 15s / first 5s / split in half),
  live selection duration with validation (`/api/wave/:id`, `/api/wave-film/:id`)
- **Batch operations**: multi-select in the library, then compress / normalize /
  convert / merge in one go — runs sequentially in the background
- **Job queue drawer**: live progress, stop, per-job output downloads, "open chat"
  for chat jobs; finished chat results re-attach to their conversations automatically

## From 0.2
- Streaming upload to disk (no RAM crash), size limit (MAX_UPLOAD_MB, default 2048)
- Live progress bar for every ffmpeg job; Stop cancels (jobs survive browser disconnect)
- Auto-cleanup of files older than RETENTION_DAYS (default 14)
- Transcription of any length (auto-chunked, timestamps merged, 429 retry)
- 16 tools: probe, trim, convert, resize, compress, change_speed, crop_video (9:16 / 1:1 / 16:9),
  normalize_audio, remove_silence, merge_media, burn_subtitles, extract_frame, make_gif,
  transcribe_audio, analyze_video (Gemini), write_text_file
- Inline video/audio/image preview with seeking (HTTP Range)
- Manual editor + subtitle/text editor (saves as a NEW version)
- Library & versions: every output remembers its source file; originals are never overwritten
- AI remembers output file ids between messages, so chaining works; MAX_ROUNDS env (default 12)
- Security: Origin check (CSRF), Host check, html served as plain text, keys redacted from errors

## Notes
- Uploads still require the tab to stay open (browsers can't upload in the background) —
  only processing runs after you close it.
- Browser notifications need the tab open in the background (Notification permission);
  the OS notification from the server covers the tab-closed case.
- burn_subtitles needs an ffmpeg build with libass; non-Latin fonts depend on your system fonts.
- analyze_video sends a small 360p proxy to Gemini, so keep clips to a few minutes.

## Not built yet
Lyrics Studio, beat detection, visualizer, multi-track timeline, GitHub Skills manager, PDF/DOCX tools.

