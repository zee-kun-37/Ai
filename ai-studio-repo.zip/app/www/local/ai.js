'use strict';
// AI controller (browser port of lib/ai.js): Cohere decides which tools to call, we run them and feed results back.
(() => {
  const S = window.StudioStore, T = window.StudioTools;
  const MAX_ROUNDS = 12;
  const SYS = `You are the controller of a local AI editing studio. Uploaded and generated files are referenced by file_id.
Use tools to inspect and process files; never claim to have seen or heard a file's content unless a tool returned it.
Every tool creates a NEW file (the original is never changed), so you can chain tools: use the file_id of a previous output as the input of the next step.
Plan briefly, call tools, then report what you did in a short reply. Reply in the same language the user writes in (Hindi/Hinglish/English).
If a tool fails, explain the error simply and suggest a fix. Ask only when a required detail (like a time range) is truly missing.`;

  async function chat(msgs, c) {
    const key = S.loadSettings().cohere;
    if (!key) throw new Error('Cohere API key not set. Open Settings.');
    const m = [{ role: 'system', content: SYS }, ...msgs], steps = [];
    for (let i = 0; i < MAX_ROUNDS; i++) {
      c.emit({ t: 'status', text: i ? 'Thinking…' : 'Planning…' });
      const r = await T.http('https://api.cohere.com/v2/chat', { sig: c.sig, headers: { Authorization: 'Bearer ' + key },
        json: { model: 'command-a-03-2025', messages: m, tools: T.toolDefs } });
      if (r.status === 401 || r.status === 403) throw new Error('Cohere rejected the API key.');
      if (r.status === 429) throw new Error('Cohere rate limit reached. Wait a moment and retry.');
      if (!r.ok) throw new Error('Cohere ' + r.status + ': ' + S.redact((await r.text()).slice(0, 300)));
      const msg = (await r.json()).message;
      if (!msg.tool_calls || !msg.tool_calls.length) return { text: (msg.content || []).map(x => x.text || '').join(''), steps };
      m.push({ role: 'assistant', tool_plan: msg.tool_plan, tool_calls: msg.tool_calls });
      for (const tc of msg.tool_calls) {
        const n = tc.function.name; let a = {}, res;
        c.emit({ t: 'status', text: 'Running ' + n + '…' });
        try {
          a = JSON.parse(tc.function.arguments || '{}');
          if (!T.TOOLS[n]) throw new Error('Unknown tool');
          res = (await T.TOOLS[n].run(a, c)).result; steps.push({ tool: n, args: a, ok: true });
        } catch (e) {
          if (e.name === 'AbortError') throw e;
          res = { error: S.redact(e.message) }; steps.push({ tool: n, args: a, ok: false, error: res.error });
        }
        m.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(res) });
      }
    }
    return { text: `Stopped after ${MAX_ROUNDS} tool rounds. Say "continue" to go on.`, steps };
  }
  window.StudioAI = { chat };
})();
