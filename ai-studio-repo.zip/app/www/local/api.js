'use strict';
// The in-app "server": answers the same /api/* calls the UI already makes, but locally.
// window.fetch is wrapped so app.js keeps working unchanged; uploads, media URLs and
// waveform pictures go through window.LocalStudio (4 tiny hooks in app.js).
(() => {
  const S = window.StudioStore, E = window.StudioEngine, J = window.StudioJobs, T = window.StudioTools, AI = window.StudioAI;
  const nativeFetch = window.fetch.bind(window);
  const ready = (async () => { await S.init(); await J.init(); S.cleanup().catch(() => {}); setInterval(() => S.cleanup().catch(() => {}), 3600e3); })();

  const json = (code, o) => new Response(JSON.stringify(o), { status: code, headers: { 'Content-Type': 'application/json' } });
  const bodyJson = init => { try { return JSON.parse((init && init.body) || '{}'); } catch { throw new Error('Bad JSON'); } };

  // NDJSON event stream for a job. Cancelling the reader only detaches - the job keeps running.
  function streamJob(handle) {
    const enc = new TextEncoder(); let send;
    return new Response(new ReadableStream({
      start(ctl) {
        send = o => {
          try { ctl.enqueue(enc.encode(JSON.stringify(o) + '\n')); } catch { handle.listeners.delete(send); return; }
          if (o.t === 'done' || o.t === 'error') { handle.listeners.delete(send); try { ctl.close(); } catch {} }
        };
        handle.listeners.add(send);
      },
      cancel() { handle.listeners.delete(send); },
    }), { status: 200, headers: { 'Content-Type': 'application/x-ndjson' } });
  }

  const TEST_URLS = {
    cohere: k => ['https://api.cohere.com/v1/models', { Authorization: 'Bearer ' + k }],
    groq: k => ['https://api.groq.com/openai/v1/models', { Authorization: 'Bearer ' + k }],
    gemini: k => ['https://generativelanguage.googleapis.com/v1beta/models', { 'x-goog-api-key': k }],
    github: k => ['https://api.github.com/user', { Authorization: 'Bearer ' + k }],
  };
  let healthP = null;

  async function route(u, M, init) {
    await ready;
    const P = u.pathname;
    if (P === '/api/health') { healthP = healthP || E.available().catch(() => false); const ok = await healthP; return json(200, { ffmpeg: ok, ffprobe: ok }); }
    if (P === '/api/settings' && M === 'GET') { const s = S.loadSettings(); return json(200, Object.fromEntries(S.PROVIDERS.map(k => [k, !!s[k]]))); }
    if (P === '/api/settings' && M === 'POST') {
      const j = bodyJson(init), s = S.loadSettings();
      for (const k of S.PROVIDERS) if (k in j) { if (j[k]) s[k] = String(j[k]).trim(); else delete s[k]; }
      S.saveSettings(s); return json(200, { ok: true });
    }
    if (P === '/api/test') {
      const p = u.searchParams.get('p'), k = S.loadSettings()[p];
      if (!TEST_URLS[p] || !k) return json(200, { ok: false, msg: 'No key saved' });
      const [url, headers] = TEST_URLS[p](k);
      try { const r = await T.http(url, { method: 'GET', headers }); return json(200, { ok: r.ok, msg: r.ok ? 'Connected' : 'Rejected (' + r.status + ')' }); }
      catch { return json(200, { ok: false, msg: 'Network error' }); }
    }
    if (P === '/api/files' && M === 'GET') return json(200, S.listFiles());
    if (P.startsWith('/api/file/')) {
      const id = P.split('/')[3];
      if (M === 'DELETE') return json(200, { ok: await S.removeFile(id) });
      try { const f = S.need(id); return new Response(f.blob, { headers: { 'Content-Type': S.mimeOf(f.name) } }); } catch { return json(404, { error: 'not found' }); }
    }
    if (P.startsWith('/api/text/')) {
      let f; try { f = S.need(P.split('/')[3]); } catch { return json(404, { error: 'not found' }); }
      if (!/^text\/plain/.test(S.mimeOf(f.name)) || f.blob.size > 2e6) return json(400, { error: 'Not an editable text file' });
      return json(200, { name: f.name, text: await f.blob.text() });
    }
    if (P === '/api/savetext' && M === 'POST') { // saving an edit creates a NEW version; the original stays untouched
      const j = bodyJson(init), o = S.outPath(j.name || 'edited.txt', j.parent);
      return json(200, await S.finish(o, new Blob([String(j.text || '')])));
    }
    if (P === '/api/tool' && M === 'POST') {
      const j = bodyJson(init);
      if (!T.TOOLS[j.name]) return json(400, { error: 'Unknown tool' });
      const label = String(j.label || j.name).slice(0, 60);
      const h = J.runJob('tool', label, { name: j.name, chat_id: j.chat_id || null }, async c => ({ result: (await T.TOOLS[j.name].run(j.args || {}, c)).result }));
      return streamJob(h);
    }
    if (P === '/api/chat' && M === 'POST') {
      const j = bodyJson(init), label = String(j.label || 'AI request').slice(0, 60);
      return streamJob(J.runJob('chat', label, { chat_id: j.chat_id || null }, c => AI.chat(j.messages || [], c)));
    }
    if (P === '/api/jobs' && M === 'GET') return json(200, { jobs: J.listJobs() });
    if (P.startsWith('/api/jobs/') && M === 'POST') {
      const parts = P.split('/');
      if (parts[4] === 'stop') return json(200, { ok: J.stopJob(parts[3]) });
    }
    return json(404, { error: 'not found' });
  }

  window.fetch = (input, init) => {
    const raw = typeof input === 'string' ? input : (input && input.url) || '';
    if (!/^\/api\//.test(raw)) return nativeFetch(input, init);
    return route(new URL(raw, 'http://x'), ((init && init.method) || 'GET').toUpperCase(), init)
      .catch(e => json(500, { error: S.redact(e.message) }));
  };

  // ---------- hooks used by app.js ----------
  async function upload(file, onProgress) {
    await ready;
    const id = S.newId(), name = S.safeName(file.name);
    if (onProgress) onProgress(50);
    await S.put(id, name, file, null);
    if (onProgress) onProgress(100);
    return { id, name, size: file.size };
  }
  const picCache = new Map();
  async function pic(id, film) {
    await ready;
    const key = id + (film ? ':film' : ':wave');
    if (picCache.has(key)) return picCache.get(key);
    const blob = await E_wave(S.need(id), film);
    if (!blob) throw new Error('no picture');
    const u = URL.createObjectURL(blob); picCache.set(key, u); return u;
  }
  const E_wave = (f, film) => T.wavePic(f, film);

  // Save/share an output on a phone (WebView ignores <a download> on blob: links).
  async function save(name, blob) {
    const cap = window.Capacitor, P = cap && cap.Plugins;
    if (!(cap && cap.isNativePlatform && cap.isNativePlatform() && P && P.Filesystem && P.Share)) return false;
    const path = 'studio-share/' + name, CH = 3 * 1024 * 1024;
    try { await P.Filesystem.rmdir({ path: 'studio-share', directory: 'CACHE', recursive: true }); } catch {}
    for (let o = 0, first = true; o < blob.size || first; o += CH, first = false) {
      const data = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1] || ''); r.onerror = () => no(r.error); r.readAsDataURL(blob.slice(o, o + CH)); });
      if (first) await P.Filesystem.writeFile({ path, data, directory: 'CACHE', recursive: true });
      else await P.Filesystem.appendFile({ path, data, directory: 'CACHE' });
    }
    const { uri } = await P.Filesystem.getUri({ path, directory: 'CACHE' });
    await P.Share.share({ title: name, url: uri, dialogTitle: 'Save / share ' + name });
    return true;
  }
  document.addEventListener('click', e => {
    const a = e.target && e.target.closest && e.target.closest('a[download]');
    if (!a || !/^blob:/.test(a.href)) return;
    const b = S.blobOfUrl(a.href); if (!b) return;
    const cap = window.Capacitor; if (!(cap && cap.isNativePlatform && cap.isNativePlatform())) return; // browsers handle blob downloads natively
    e.preventDefault();
    save(a.download || b.name || 'file', b.blob).catch(err => alert('Could not save: ' + err.message));
  }, true);

  window.LocalStudio = { url: id => S.url(id), upload, pic, save, ready };
  // warm up the ffmpeg engine in the background so the first job starts fast
  ready.then(() => { setTimeout(() => { E.preload().catch(() => {}); }, 1500); });
})();
