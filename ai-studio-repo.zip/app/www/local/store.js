'use strict';
// In-app storage (replaces the server's disk + settings + jobs.json).
// Files and their metadata live in IndexedDB; API keys in localStorage.
(() => {
  const RETENTION_DAYS = 14;
  const PROVIDERS = ['cohere', 'groq', 'gemini', 'github'];
  let db;
  const meta = new Map(), blobs = new Map(), urls = new Map(), url2blob = new Map();

  const rq = r => new Promise((ok, no) => { r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error); });
  const done = t => new Promise((ok, no) => { t.oncomplete = () => ok(); t.onerror = () => no(t.error); t.onabort = () => no(t.error); });
  const openDb = () => new Promise((ok, no) => {
    const r = indexedDB.open('ai-studio', 1);
    r.onupgradeneeded = () => { const d = r.result; d.createObjectStore('meta', { keyPath: 'id' }); d.createObjectStore('blob'); d.createObjectStore('kv'); };
    r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error);
  });

  async function init() {
    db = await openDb();
    for (const m of await rq(db.transaction('meta').objectStore('meta').getAll())) meta.set(m.id, m);
    await new Promise((ok, no) => { // blob handles are lazy / disk-backed, cheap to hold
      const c = db.transaction('blob').objectStore('blob').openCursor();
      c.onsuccess = () => { const cur = c.result; if (!cur) return ok(); blobs.set(cur.key, cur.value); cur.continue(); };
      c.onerror = () => no(c.error);
    });
    for (const id of [...meta.keys()]) if (!blobs.has(id)) meta.delete(id); // orphan metadata
  }

  // ---------- settings ----------
  const loadSettings = () => { try { return JSON.parse(localStorage.getItem('studio.settings') || '{}'); } catch { return {}; } };
  const saveSettings = s => localStorage.setItem('studio.settings', JSON.stringify(s));
  function redact(t) {
    const s = loadSettings(); t = String(t);
    for (const k of PROVIDERS) if (s[k] && s[k].length > 6) t = t.split(s[k]).join('[key]');
    return t;
  }

  // ---------- pure utilities (same behaviour as lib/core.js) ----------
  const newId = () => [...crypto.getRandomValues(new Uint8Array(4))].map(b => b.toString(16).padStart(2, '0')).join('');
  const safeName = n => String(n || 'file').split(/[\\/]/).pop().replace(/[^\w.\- ]/g, '_') || 'file';
  const stem = n => n.replace(/\.[^.]+$/, '');
  const extname = n => { const m = /\.[^.\/]+$/.exec(n); return m ? m[0] : ''; };
  const num = (v, d, lo, hi) => { v = Number(v); if (!Number.isFinite(v)) v = d; return Math.min(hi, Math.max(lo, v)); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const srtTime = s => {
    const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = (s % 60).toFixed(3).padStart(6, '0').replace('.', ',');
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${x}`;
  };
  function atempoChain(s) {
    const f = [];
    while (s > 2) { f.push('atempo=2'); s /= 2; }
    while (s < 0.5) { f.push('atempo=0.5'); s /= 0.5; }
    f.push('atempo=' + s.toFixed(4));
    return f.join(',');
  }
  function parseSilence(txt, dur) {
    const out = []; let s = null;
    for (const l of String(txt).split('\n')) {
      let m = /silence_start: (-?[\d.]+)/.exec(l); if (m) s = Math.max(0, +m[1]);
      m = /silence_end: ([\d.]+)/.exec(l); if (m && s !== null) { out.push({ s, e: +m[1] }); s = null; }
    }
    if (s !== null) out.push({ s, e: dur });
    return out;
  }
  function keepSegments(sil, dur, pad = 0.08, minKeep = 0.15) {
    const k = []; let cur = 0;
    for (const x of sil) { if (x.s + pad > cur) k.push([cur, x.s + pad]); cur = Math.max(cur, x.e - pad); }
    if (dur > cur) k.push([cur, dur]);
    return k.filter(([a, b]) => b - a >= minKeep);
  }
  function cropBox(w, h, rw, rh) {
    let cw = w, ch = Math.round(w * rh / rw);
    if (ch > h) { ch = h; cw = Math.round(h * rw / rh); }
    return { cw: cw - cw % 2, ch: ch - ch % 2 };
  }
  const MIMES = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska',
    '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg', '.flac': 'audio/flac',
    '.gif': 'image/gif', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
    '.srt': 'text/plain; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.csv': 'text/plain; charset=utf-8',
    '.md': 'text/plain; charset=utf-8', '.html': 'text/plain; charset=utf-8' };
  const mimeOf = n => MIMES[extname(n).toLowerCase()] || 'application/octet-stream';

  // ---------- file registry ----------
  async function put(id, name, blob, parent) {
    blob = blob.slice(0, blob.size, mimeOf(name)); // give it a proper type so <video>/<audio> accept the object URL
    const m = { id, name, size: blob.size, parent: parent || null, t: Date.now() };
    const t = db.transaction(['meta', 'blob'], 'readwrite');
    t.objectStore('blob').put(blob, id); t.objectStore('meta').put(m);
    await done(t);
    // re-read so we hold the disk-backed handle instead of keeping the whole thing in RAM
    const stored = await rq(db.transaction('blob').objectStore('blob').get(id));
    meta.set(id, m); blobs.set(id, stored || blob);
    return m;
  }
  const outPath = (name, parent) => ({ id: newId(), name: safeName(name), parent: parent || null });
  async function finish(o, blob) {
    if (!blob || blob.size === 0) throw new Error('FFmpeg produced no output');
    const m = await put(o.id, o.name, blob, o.parent);
    return { id: m.id, name: m.name, size: m.size, parent: m.parent };
  }
  function need(id) {
    const m = meta.get(id);
    if (!m || !blobs.has(id)) throw new Error('Unknown file id ' + id);
    return { ...m, blob: blobs.get(id) };
  }
  const listFiles = () => [...meta.values()].map(m => ({ id: m.id, name: m.name, size: m.size, parent: m.parent, t: m.t })).sort((a, b) => b.t - a.t);
  async function removeFile(id) {
    if (!meta.has(id)) return false;
    const t = db.transaction(['meta', 'blob'], 'readwrite'); t.objectStore('blob').delete(id); t.objectStore('meta').delete(id); await done(t);
    meta.delete(id); blobs.delete(id);
    const u = urls.get(id); if (u) { URL.revokeObjectURL(u); url2blob.delete(u); urls.delete(id); }
    return true;
  }
  async function cleanup() {
    const limit = Date.now() - RETENTION_DAYS * 864e5; let n = 0;
    for (const m of [...meta.values()]) if (m.t < limit) { await removeFile(m.id); n++; }
    return n;
  }
  // synchronous object URL for <video>/<img>/<a download>; Range/seek is handled natively by the browser
  function url(id) {
    if (urls.has(id)) return urls.get(id);
    const b = blobs.get(id); if (!b) return '';
    const u = URL.createObjectURL(b); urls.set(id, u); url2blob.set(u, { blob: b, name: (meta.get(id) || {}).name }); return u;
  }
  const blobOfUrl = u => url2blob.get(u) || null;

  // ---------- generic key/value (jobs) ----------
  const kvGet = async k => rq(db.transaction('kv').objectStore('kv').get(k));
  const kvSet = async (k, v) => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); await done(t); };

  window.StudioStore = { RETENTION_DAYS, PROVIDERS, init, loadSettings, saveSettings, redact, newId, safeName, stem, extname, num, sleep, srtTime,
    atempoChain, parseSilence, keepSegments, cropBox, mimeOf, put, outPath, finish, need, listFiles, removeFile, cleanup, url, blobOfUrl, kvGet, kvSet };
})();
