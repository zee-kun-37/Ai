'use strict';
// FFmpeg engine that runs INSIDE the app (ffmpeg.wasm in a Web Worker) - no server, no Termux.
// Runs are serialized (one ffmpeg at a time). Inputs are mounted with WORKERFS (no RAM copy);
// outputs land in the in-memory FS and are returned as Blobs.
(() => {
  const S = window.StudioStore;
  const abs = p => new URL(p, document.baseURI).href;
  const IN = (i, f) => '/in' + i + '/' + f.name; // path of input #i inside the engine
  const W = '/w/';                                // scratch/output dir inside the engine
  const abortErr = () => { const e = new Error('Cancelled'); e.name = 'AbortError'; return e; };

  // ---------- backend: ffmpeg.wasm ----------
  function wasmBackend() {
    let ff = null, loading = null, logCb = null;
    return {
      async available() {
        if (typeof FFmpegWASM === 'undefined') return false;
        try { return (await fetch(abs('local/ffmpeg/ffmpeg-core.js'))).ok; } catch { return false; }
      },
      async load() {
        if (ff) return;
        if (!loading) loading = (async () => {
          if (typeof FFmpegWASM === 'undefined') throw new Error('FFmpeg engine files are missing from the app (local/ffmpeg). Rebuild the APK.');
          const f = new FFmpegWASM.FFmpeg();
          f.on('log', e => { if (logCb) logCb(e.message); });
          await f.load({ coreURL: abs('local/ffmpeg/ffmpeg-core.js'), wasmURL: abs('local/ffmpeg/ffmpeg-core.wasm') });
          ff = f;
        })().finally(() => { loading = null; });
        await loading;
      },
      setLog(cb) { logCb = cb; },
      exec: args => ff.exec(args),
      mkdir: p => ff.createDir(p).catch(() => {}),
      rmdir: p => ff.deleteDir(p).catch(() => {}),
      write: (p, d) => ff.writeFile(p, d),
      async read(p) { return ff.readFile(p); },
      async list(p) { return (await ff.listDir(p)).filter(x => !x.isDir).map(x => x.name); },
      rm: p => ff.deleteFile(p).catch(() => {}),
      async mount(i, f) { await ff.createDir('/in' + i); await ff.mount('WORKERFS', { blobs: [{ name: f.name, data: f.blob }] }, '/in' + i); },
      async unmount(i) { await ff.unmount('/in' + i).catch(() => {}); await ff.deleteDir('/in' + i).catch(() => {}); },
      terminate() { try { ff && ff.terminate(); } catch {} ff = null; },
    };
  }

  let B = wasmBackend();
  let chain = Promise.resolve();
  const serial = fn => { const p = chain.then(() => fn()); chain = p.catch(() => {}); return p; };
  let fontData = null;
  const getFont = async () => {
    if (fontData) return fontData;
    try { const r = await fetch(abs('local/font.ttf')); if (!r.ok) throw 0; return (fontData = new Uint8Array(await r.arrayBuffer())); }
    catch { const e = new Error('Subtitle font (local/font.ttf) is missing from the app. Rebuild the APK.'); e.own = true; throw e; }
  };

  const tail = logs => logs.join('\n').slice(-600);

  /**
   * o.inputs   [{name, blob}]  -> readable at IN(i, file)
   * o.steps    [[args], ...]   (or o.args for a single run) - run in order, args use W for outputs
   * o.files    [{name, data}]  small helper files written into W
   * o.outputs  ['o.mp4']       names inside W to return as Blobs
   * o.collect  /regex/         also return every file in W whose name matches
   * o.duration seconds, for progress %   o.onProgress(pct)   o.sig AbortSignal   o.fonts true -> /fonts/font.ttf
   * o.allowFail true -> a non-zero exit is not an error (used for probing / silencedetect)
   */
  function run(o) {
    return serial(async () => {
      if (o.sig && o.sig.aborted) throw abortErr();
      await B.load();
      const logs = []; let killed = false;
      const onAbort = () => { killed = true; B.terminate(); };
      if (o.sig) o.sig.addEventListener('abort', onAbort, { once: true });
      B.setLog(m => {
        logs.push(m); if (logs.length > 600) logs.shift();
        const t = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(m);
        if (t && o.duration > 0 && o.onProgress) o.onProgress(Math.min(99, Math.round((+t[1] * 3600 + +t[2] * 60 + +t[3]) / o.duration * 100)));
      });
      const mounted = [];
      try {
        await B.mkdir('/w');
        if (o.fonts) { await B.mkdir('/fonts'); await B.write('/fonts/font.ttf', await getFont()); }
        for (const [i, f] of (o.inputs || []).entries()) { await B.mount(i, f); mounted.push(i); }
        for (const f of o.files || []) await B.write(W + f.name, f.data);
        let code = 0;
        for (const args of (o.steps || [o.args])) {
          code = await B.exec(['-hide_banner', '-y', ...args]);
          if (code !== 0 && !o.allowFail) { const e = new Error(S.redact(tail(logs)) || 'ffmpeg failed (exit ' + code + ')'); e.own = true; throw e; }
        }
        const outputs = {};
        const names = [...(o.outputs || [])];
        if (o.collect) for (const n of await B.list('/w')) if (o.collect.test(n) && !names.includes(n)) names.push(n);
        for (const n of names) { try { outputs[n] = new Blob([await B.read(W + n)]); } catch { /* missing output is reported by the caller */ } }
        return { outputs, log: logs.join('\n'), code };
      } catch (e) {
        if (killed || (o.sig && o.sig.aborted)) throw abortErr();
        if (!e.own) { B.terminate(); throw new Error('FFmpeg crashed (probably out of memory). Try a smaller file or a lower resolution. ' + S.redact(String(e.message || e)).slice(0, 120)); }
        throw e;
      } finally {
        if (o.sig) o.sig.removeEventListener('abort', onAbort);
        B.setLog(null);
        if (!killed) { // best-effort cleanup of the engine's scratch space
          try {
            for (const i of mounted) await B.unmount(i);
            for (const n of await B.list('/w')) await B.rm(W + n);
            await B.rmdir('/w');
          } catch { B.terminate(); }
        }
      }
    });
  }

  // ---------- probe (parses `ffmpeg -i` output; no ffprobe needed) ----------
  function parseProbe(txt, size) {
    const d = /Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/.exec(txt);
    const duration = d ? +d[1] * 3600 + +d[2] * 60 + +d[3] : 0;
    const streams = []; let v = null, a = null;
    for (const l of String(txt).split('\n')) {
      const m = /Stream #\d+:\d+(?:\[[^\]]*\])?(?:\([^)]*\))?: (Video|Audio|Subtitle|Data|Attachment): ([^\s,(]+)(.*)$/.exec(l);
      if (!m) continue;
      const type = m[1].toLowerCase(), rest = m[3], s = { type, codec: m[2] };
      if (type === 'video') {
        const wh = /[ ,](\d{2,5})x(\d{2,5})(?=[ ,\[])/.exec(rest); if (wh) { s.w = +wh[1]; s.h = +wh[2]; }
        const fps = /(\d+(?:\.\d+)?) fps/.exec(rest) || /(\d+(?:\.\d+)?) tbr/.exec(rest); if (fps) s.fps = fps[1];
        s.attached = /attached pic/.test(l);
        if (!s.attached && !v) v = s;
      } else if (type === 'audio') {
        s.ch = /mono/.test(rest) ? 1 : /stereo/.test(rest) ? 2 : (/(\d+)\.(\d)/.exec(rest) ? +RegExp.$1 + +RegExp.$2 : (/(\d+) channels/.exec(rest) || [0, 0])[1] * 1);
        if (!a) a = s;
      }
      streams.push(s);
    }
    return { duration, size: size || 0, hasVideo: !!v, hasAudio: !!a, w: v ? v.w || 0 : 0, h: v ? v.h || 0 : 0,
      streams: streams.map(s => ({ type: s.type, codec: s.codec, w: s.w, h: s.h, fps: s.fps, ch: s.ch })) };
  }
  const probeCache = new Map();
  async function probe(f, sig) {
    if (f.id && probeCache.has(f.id)) return probeCache.get(f.id);
    const r = await run({ inputs: [f], steps: [['-i', IN(0, f)]], allowFail: true, sig });
    const info = parseProbe(r.log, f.blob.size);
    if (!info.duration && !info.streams.length) throw new Error('Cannot read this media file: ' + f.name);
    if (f.id) probeCache.set(f.id, info);
    return info;
  }

  window.StudioEngine = { run, probe, parseProbe, IN, W, available: () => B.available(), preload: () => B.load(),
    _setBackend: b => { B = b; } }; // _setBackend: used by the Node test-suite
})();
