'use strict';
// Background job manager (browser port of lib/jobs.js). Jobs run inside the app; leaving a screen
// or closing a dialog never stops them. Job list is persisted in IndexedDB.
(() => {
  const S = window.StudioStore;
  const MAX_JOBS = 120;
  let jobs = {}, timer = null;
  const running = new Map();

  async function init() {
    jobs = (await S.kvGet('jobs')) || {};
    for (const j of Object.values(jobs)) if (j.status === 'running') { j.status = 'interrupted'; j.error = 'The app was closed while this job was running. Run it again.'; }
    persist();
  }
  function persist() {
    if (timer) return;
    timer = setTimeout(() => { timer = null; S.kvSet('jobs', jobs).catch(() => {}); }, 400);
  }
  function trimJobs() {
    const ks = Object.keys(jobs).sort((a, b) => (jobs[b].updated || 0) - (jobs[a].updated || 0));
    while (ks.length > MAX_JOBS) delete jobs[ks.pop()];
  }
  function runJob(kind, label, meta, fn) {
    const ac = new AbortController(), id = S.newId();
    const job = { id, kind, label, status: 'running', pct: 0, progLabel: '', outputs: [], created: Date.now(), updated: Date.now(), ...(meta || {}) };
    jobs[id] = job; trimJobs(); persist(); running.set(id, ac);
    const listeners = new Set();
    const emit = o => {
      if (o.t === 'prog') { job.pct = o.pct; job.progLabel = o.label || job.progLabel; }
      if (o.t === 'status') job.progLabel = o.text || job.progLabel;
      job.updated = Date.now(); persist();
      for (const l of [...listeners]) { try { l(o); } catch { listeners.delete(l); } }
    };
    const c = { sig: ac.signal, out: job.outputs, emit };
    (async () => {
      let final;
      try {
        job.result = await fn(c);
        job.status = 'done';
        final = { t: 'done', ...job.result, outputs: job.outputs, jobId: id };
      } catch (e) {
        if (e.name === 'AbortError' || ac.signal.aborted) { job.status = 'cancelled'; final = { t: 'error', error: 'Cancelled', outputs: job.outputs, jobId: id }; }
        else { job.status = 'error'; job.error = S.redact(e.message); final = { t: 'error', error: job.error, outputs: job.outputs, jobId: id }; }
      }
      job.updated = Date.now(); persist();
      if (window.StudioNotify) window.StudioNotify(job);
      for (const l of [...listeners]) { try { l(final); } catch {} }
      listeners.clear(); running.delete(id);
    })();
    return { job, listeners, ac };
  }
  const listJobs = () => Object.values(jobs).sort((a, b) => (b.created || 0) - (a.created || 0));
  function stopJob(id) {
    const j = jobs[id]; if (!j || j.status !== 'running') return false;
    const ac = running.get(id); if (ac) ac.abort(); return true;
  }
  window.StudioJobs = { init, runJob, listJobs, stopJob };
})();
