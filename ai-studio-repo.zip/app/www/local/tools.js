'use strict';
// Browser port of studio/lib/tools.js - same 16 tools, same arguments, same results,
// but every ffmpeg call runs in the in-app engine instead of a server process.
(() => {
  const S = window.StudioStore, E = window.StudioEngine;
  const { need, stem, num, outPath, redact, extname } = S;
  const { IN, W } = E;

  const extOf = (f, d = '.mp4') => extname(f.name) || d;
  const probe = (f, sig) => E.probe(f, sig);
  const done = async (c, o, blob) => { const r = await S.finish(o, blob); c.out.push(r); return { result: r }; };
  const prog = (c, label) => pct => c.emit && c.emit({ t: 'prog', pct, label });

  // HTTP helper: the native HTTP plugin (when running as an APK) avoids browser CORS limits for APIs like Cohere.
  async function http(url, { method = 'POST', headers = {}, json, body, sig } = {}) {
    const cap = window.Capacitor, plug = cap && cap.Plugins && cap.Plugins.CapacitorHttp;
    if (plug && json !== undefined && cap.isNativePlatform && cap.isNativePlatform()) {
      if (sig && sig.aborted) { const e = new Error('Cancelled'); e.name = 'AbortError'; throw e; }
      const r = await plug.request({ url, method, headers: { 'Content-Type': 'application/json', ...headers }, data: json });
      if (sig && sig.aborted) { const e = new Error('Cancelled'); e.name = 'AbortError'; throw e; }
      const txt = typeof r.data === 'string' ? r.data : JSON.stringify(r.data);
      return { ok: r.status >= 200 && r.status < 300, status: r.status, text: async () => txt, json: async () => (typeof r.data === 'string' ? JSON.parse(r.data) : r.data) };
    }
    return fetch(url, { method, headers: json !== undefined ? { 'Content-Type': 'application/json', ...headers } : headers, body: json !== undefined ? JSON.stringify(json) : body, signal: sig });
  }
  const b64 = blob => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(',')[1] || ''); r.onerror = () => no(r.error); r.readAsDataURL(blob); });

  // Single-input encode: probe -> ffmpeg with progress -> register output (parent = input, for version history).
  async function encode(c, f, { tag, ext, args, pre = [], label, dur }) {
    const info = await probe(f, c.sig);
    const o = outPath(stem(f.name) + tag + ext, f.id), out = 'o' + ext;
    // wasm is single-threaded: use the fast x264 / VP9 settings, but only when a video stream is really re-encoded
    // (ffmpeg aborts on codec options that no stream uses, e.g. -preset on an mp3 or on -c:v copy)
    const vcopy = args.some((x, k) => x === '-c:v' && args[k + 1] === 'copy');
    const fast = !info.hasVideo || vcopy || args.includes('-preset') ? [] : ['.mp4', '.mov', '.mkv'].includes(ext) ? ['-preset', 'veryfast'] : ext === '.webm' ? ['-deadline', 'realtime', '-cpu-used', '8'] : [];
    const r = await E.run({ inputs: [f], args: [...pre, '-i', IN(0, f), ...args, ...fast, W + out], outputs: [out], duration: dur || info.duration, onProgress: prog(c, label), sig: c.sig });
    return done(c, o, r.outputs[out]);
  }

  // ---- Groq Whisper (chunked so any length works) ----
  async function groqChunk(blob, key, lang, sig) {
    for (let t = 0; t < 3; t++) {
      const fd = new FormData();
      fd.append('file', blob, 'a.mp3');
      fd.append('model', 'whisper-large-v3'); fd.append('response_format', 'verbose_json');
      fd.append('timestamp_granularities[]', 'word'); fd.append('timestamp_granularities[]', 'segment');
      if (lang) fd.append('language', lang);
      const r = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', { method: 'POST', headers: { Authorization: 'Bearer ' + key }, body: fd, signal: sig });
      if (r.status === 429 && t < 2) { await S.sleep(6000 * (t + 1)); continue; }
      if (!r.ok) throw new Error('Groq ' + r.status + ': ' + redact((await r.text()).slice(0, 300)));
      return r.json();
    }
  }
  async function transcribe(a, c) {
    const key = S.loadSettings().groq; if (!key) throw new Error('Groq API key not set in Settings');
    const f = need(a.file_id), info = await probe(f, c.sig);
    const r = await E.run({ inputs: [f], collect: /^c\d+\.mp3$/, duration: info.duration, onProgress: prog(c, 'Preparing audio'), sig: c.sig,
      args: ['-i', IN(0, f), '-vn', '-ac', '1', '-ar', '16000', '-b:a', '48k', '-f', 'segment', '-segment_time', '1200', '-reset_timestamps', '1', W + 'c%03d.mp3'] });
    const names = Object.keys(r.outputs).sort();
    if (!names.length) throw new Error('No audio found in file');
    let offset = 0; const text = [], segments = [], words = []; let language = '';
    for (let i = 0; i < names.length; i++) {
      c.emit({ t: 'prog', pct: Math.round(i / names.length * 100), label: `Transcribing part ${i + 1}/${names.length}` });
      const blob = r.outputs[names[i]], j = await groqChunk(blob, key, a.language, c.sig);
      language = language || j.language; text.push((j.text || '').trim());
      for (const s of j.segments || []) segments.push({ start: s.start + offset, end: s.end + offset, text: s.text });
      for (const w of j.words || []) words.push([w.word, +(w.start + offset).toFixed(2), +(w.end + offset).toFixed(2)]);
      offset += (await probe({ name: names[i], blob }, c.sig)).duration;
    }
    const srt = segments.map((s, i) => `${i + 1}\n${S.srtTime(s.start)} --> ${S.srtTime(s.end)}\n${s.text.trim()}\n`).join('\n');
    const full = text.join(' ');
    const o1 = outPath(stem(f.name) + '.srt', f.id), o2 = outPath(stem(f.name) + '.txt', f.id);
    const r1 = await S.finish(o1, new Blob([srt])), r2 = await S.finish(o2, new Blob([full])); c.out.push(r1, r2);
    return { result: { language, duration: info.duration, srt_file_id: r1.id, txt_file_id: r2.id, text: full.slice(0, 6000), words: words.slice(0, 400) } };
  }

  // ---- Gemini video understanding (small proxy copy so it fits the inline limit) ----
  async function analyze(a, c) {
    const key = S.loadSettings().gemini; if (!key) throw new Error('Gemini API key not set in Settings');
    const f = need(a.file_id), info = await probe(f, c.sig);
    const out = info.hasVideo ? 'p.mp4' : 'p.mp3';
    const args = info.hasVideo
      ? ['-i', IN(0, f), '-vf', 'scale=-2:360,fps=2', '-c:v', 'libx264', '-crf', '34', '-preset', 'veryfast', '-ac', '1', '-b:a', '32k', '-movflags', '+faststart', W + out]
      : ['-i', IN(0, f), '-vn', '-ac', '1', '-ar', '16000', '-b:a', '32k', W + out];
    const r = await E.run({ inputs: [f], args, outputs: [out], duration: info.duration, onProgress: prog(c, 'Preparing for Gemini'), sig: c.sig });
    const blob = r.outputs[out];
    if (!blob || blob.size > 18e6) throw new Error('Too long for Gemini inline analysis. Trim it to a shorter clip first.');
    c.emit({ t: 'prog', pct: 99, label: 'Gemini is watching…' });
    const body = { contents: [{ parts: [{ inline_data: { mime_type: info.hasVideo ? 'video/mp4' : 'audio/mpeg', data: await b64(blob) } },
      { text: a.question || 'Describe this video: scenes, people, speech, text on screen and notable moments with timestamps.' }] }] };
    const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', {
      method: 'POST', signal: c.sig, headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!res.ok) throw new Error('Gemini ' + res.status + ': ' + redact((await res.text()).slice(0, 300)));
    const j = await res.json();
    const t = (((j.candidates || [])[0] || {}).content || { parts: [] }).parts.map(p => p.text || '').join('');
    if (!t) throw new Error('Gemini returned no text');
    return { result: { analysis: t } };
  }

  // ---- merge (concat) ----
  async function merge(a, c) {
    const ids = String(a.file_ids || '').split(/[\s,]+/).filter(Boolean);
    if (ids.length < 2) throw new Error('Give at least 2 file ids, comma separated');
    const fl = ids.map(need), infos = []; for (const f of fl) infos.push(await probe(f, c.sig));
    const video = infos.every(i => i.hasVideo);
    if (!video && infos.some(i => i.hasVideo)) throw new Error('Cannot mix video and audio-only files');
    if (infos.some(i => !i.hasAudio)) throw new Error('Every clip needs an audio track');
    const Wd = infos[0].w - infos[0].w % 2, H = infos[0].h - infos[0].h % 2, n = fl.length;
    let g = '';
    for (let i = 0; i < n; i++) {
      if (video) g += `[${i}:v]scale=${Wd}:${H}:force_original_aspect_ratio=decrease,pad=${Wd}:${H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v${i}];`;
      g += `[${i}:a]aresample=44100,aformat=channel_layouts=stereo[a${i}];`;
    }
    g += fl.map((_, i) => (video ? `[v${i}]` : '') + `[a${i}]`).join('') + `concat=n=${n}:v=${video ? 1 : 0}:a=1${video ? '[v]' : ''}[a]`;
    const ext = video ? '.mp4' : extOf(fl[0], '.mp3'), o = outPath(stem(fl[0].name) + '_merged' + ext, fl[0].id), out = 'o' + ext;
    const args = [...fl.flatMap((f, i) => ['-i', IN(i, f)]), '-filter_complex', g, ...(video ? ['-map', '[v]', '-c:v', 'libx264', '-crf', '22', '-preset', 'veryfast'] : []), '-map', '[a]', ...(video ? ['-c:a', 'aac'] : []), W + out];
    const r = await E.run({ inputs: fl, args, outputs: [out], duration: infos.reduce((s, i) => s + i.duration, 0), onProgress: prog(c, 'Merging'), sig: c.sig });
    return done(c, o, r.outputs[out]);
  }

  // ---- silence removal ----
  async function removeSilence(a, c) {
    const f = need(a.file_id), i = await probe(f, c.sig);
    if (!i.hasAudio) throw new Error('File has no audio track');
    const db = num(a.threshold_db, -35, -80, -10), min = num(a.min_silence, 0.5, 0.1, 10);
    const det = await E.run({ inputs: [f], allowFail: true, sig: c.sig, duration: i.duration, onProgress: prog(c, 'Detecting silence'),
      args: ['-i', IN(0, f), '-vn', '-af', `silencedetect=noise=${db}dB:d=${min}`, '-f', 'null', '-'] });
    const segs = S.keepSegments(S.parseSilence(det.log, i.duration), i.duration);
    const kept = segs.reduce((s, [x, y]) => s + y - x, 0);
    if (kept >= i.duration - 0.2) return { result: { message: 'No silence found at this threshold', removed_seconds: 0 } };
    if (!segs.length) throw new Error('Everything counts as silence; lower threshold_db');
    const expr = segs.map(([x, y]) => `between(t,${x.toFixed(3)},${y.toFixed(3)})`).join('+');
    const script = (i.hasVideo ? `[0:v]select='${expr}',setpts=N/FRAME_RATE/TB[v];` : '') + `[0:a]aselect='${expr}',asetpts=N/SR/TB[a]`;
    const ext = i.hasVideo ? '.mp4' : extOf(f, '.mp3'), o = outPath(stem(f.name) + '_nosilence' + ext, f.id), out = 'o' + ext;
    const r = await E.run({ inputs: [f], files: [{ name: 'g.txt', data: script }], outputs: [out], duration: i.duration, onProgress: prog(c, 'Removing silence'), sig: c.sig,
      args: ['-i', IN(0, f), '-filter_complex_script', W + 'g.txt', ...(i.hasVideo ? ['-map', '[v]', '-c:v', 'libx264', '-crf', '22', '-preset', 'veryfast', '-c:a', 'aac'] : []), '-map', '[a]', W + out] });
    const d = await done(c, o, r.outputs[out]); d.result = { ...d.result, removed_seconds: +(i.duration - kept).toFixed(1) }; return d;
  }

  const TOOLS = {
    probe_media: { d: 'Get duration, streams, codecs, resolution of an uploaded media file.', p: { file_id: 'string' },
      async run(a, c) { const i = await probe(need(a.file_id), c.sig); return { result: { duration: i.duration, size: i.size, streams: i.streams } }; } },
    trim_media: { d: 'Cut a video/audio between start and end seconds. Re-encodes for accuracy.', p: { file_id: 'string', start: 'number', end: 'number' },
      async run(a, c) {
        const f = need(a.file_id), s = num(a.start, 0, 0, 1e6), e = num(a.end, 0, 0, 1e6);
        if (e <= s) throw new Error('end must be greater than start');
        return encode(c, f, { tag: '_trim', ext: extOf(f), args: [], pre: ['-ss', String(s), '-t', String(e - s)], label: 'Trimming', dur: e - s });
      } },
    convert_media: { d: 'Convert media to a format: mp4, webm, mkv, mov, mp3, wav, m4a, ogg, flac. Use mp3/wav to extract audio from video.', p: { file_id: 'string', format: 'string' },
      async run(a, c) {
        const f = need(a.file_id), fmt = String(a.format).toLowerCase().replace(/[^a-z0-9]/g, '');
        if (!['mp4', 'webm', 'mkv', 'mov', 'mp3', 'wav', 'm4a', 'ogg', 'flac'].includes(fmt)) throw new Error('Unsupported format: ' + fmt);
        const audio = ['mp3', 'wav', 'm4a', 'ogg', 'flac'].includes(fmt);
        return encode(c, f, { tag: '', ext: '.' + fmt, args: audio ? ['-vn'] : [], label: 'Converting' });
      } },
    resize_video: { d: 'Resize video to a target height (e.g. 720), keeping aspect ratio.', p: { file_id: 'string', height: 'number' },
      async run(a, c) {
        const f = need(a.file_id), h = Math.round(num(a.height, 720, 120, 4320));
        return encode(c, f, { tag: '_' + h + 'p', ext: '.mp4', args: ['-vf', 'scale=-2:' + h, '-c:a', 'copy'], label: 'Resizing' });
      } },
    compress_video: { d: 'Shrink video file size. quality: low (smallest), medium, high (best quality).', p: { file_id: 'string', quality: 'string (optional: low|medium|high, default medium)' },
      async run(a, c) {
        const f = need(a.file_id), crf = { low: 30, medium: 26, high: 22 }[a.quality] || 26;
        return encode(c, f, { tag: '_small', ext: '.mp4', args: ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', String(crf), '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart'], label: 'Compressing' });
      } },
    change_speed: { d: 'Change playback speed (0.25 to 8). 2 = twice as fast, 0.5 = slow motion. Pitch is preserved.', p: { file_id: 'string', speed: 'number' },
      async run(a, c) {
        const f = need(a.file_id), s = num(a.speed, 1, 0.25, 8), i = await probe(f, c.sig), args = [];
        if (i.hasVideo) args.push('-vf', 'setpts=PTS/' + s);
        if (i.hasAudio) args.push('-af', S.atempoChain(s));
        return encode(c, f, { tag: '_' + s + 'x', ext: i.hasVideo ? '.mp4' : extOf(f, '.mp3'), args, label: 'Changing speed', dur: i.duration / s });
      } },
    crop_video: { d: 'Center-crop video to a social format. preset: vertical_9x16 (Reels/Shorts/TikTok), square_1x1, landscape_16x9.', p: { file_id: 'string', preset: 'string (vertical_9x16|square_1x1|landscape_16x9)' },
      async run(a, c) {
        const P = { vertical_9x16: [9, 16, 1080, 1920], square_1x1: [1, 1, 1080, 1080], landscape_16x9: [16, 9, 1920, 1080] }[a.preset];
        if (!P) throw new Error('preset must be vertical_9x16, square_1x1 or landscape_16x9');
        const f = need(a.file_id), i = await probe(f, c.sig); if (!i.hasVideo) throw new Error('File has no video');
        const { cw, ch } = S.cropBox(i.w, i.h, P[0], P[1]);
        return encode(c, f, { tag: '_' + a.preset, ext: '.mp4', args: ['-vf', `crop=${cw}:${ch},scale=${P[2]}:${P[3]}`, '-c:a', 'copy'], label: 'Cropping' });
      } },
    normalize_audio: { d: 'Normalize loudness to a standard level (-16 LUFS) so speech is evenly loud.', p: { file_id: 'string' },
      async run(a, c) {
        const f = need(a.file_id), i = await probe(f, c.sig); if (!i.hasAudio) throw new Error('File has no audio track');
        return encode(c, f, { tag: '_norm', ext: extOf(f, '.mp3'), args: ['-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', ...(i.hasVideo ? ['-c:v', 'copy'] : [])], label: 'Normalizing audio' });
      } },
    remove_silence: { d: 'Cut out silent parts from audio/video (jump-cut style).', p: { file_id: 'string', threshold_db: 'number (optional, default -35)', min_silence: 'number (optional seconds, default 0.5)' }, run: removeSilence },
    merge_media: { d: 'Join several videos (or several audio files) one after another, in the given order.', p: { file_ids: 'string (comma separated file ids, in order)' }, run: merge },
    burn_subtitles: { d: 'Permanently draw subtitles from an .srt file onto a video.', p: { file_id: 'string', srt_file_id: 'string' },
      async run(a, c) {
        const f = need(a.file_id), s = need(a.srt_file_id), i = await probe(f, c.sig); if (!i.hasVideo) throw new Error('File has no video');
        const o = outPath(stem(f.name) + '_subs.mp4', f.id), srt = new Uint8Array(await s.blob.arrayBuffer());
        const style = "force_style='FontName=Roboto,Fontsize=22,Outline=2,MarginV=30'";
        const r = await E.run({ inputs: [f], files: [{ name: 'subs.srt', data: srt }], fonts: true, outputs: ['o.mp4'], duration: i.duration, onProgress: prog(c, 'Burning subtitles'), sig: c.sig,
          args: ['-i', IN(0, f), '-vf', `subtitles=filename='${W}subs.srt':fontsdir='/fonts':${style}`, '-preset', 'veryfast', '-c:a', 'copy', W + 'o.mp4'] });
        return done(c, o, r.outputs['o.mp4']);
      } },
    extract_frame: { d: 'Save a single frame of a video as a JPG image at a given time (seconds).', p: { file_id: 'string', time: 'number' },
      async run(a, c) {
        const f = need(a.file_id), i = await probe(f, c.sig); if (!i.hasVideo) throw new Error('File has no video');
        return encode(c, f, { tag: '_frame', ext: '.jpg', args: ['-frames:v', '1', '-q:v', '2'], pre: ['-ss', String(num(a.time, 0, 0, i.duration))], label: 'Extracting frame', dur: 1 });
      } },
    make_gif: { d: 'Make an animated GIF from a video segment (max 30s).', p: { file_id: 'string', start: 'number', duration: 'number', width: 'number (optional, default 480)' },
      async run(a, c) {
        const f = need(a.file_id), d = num(a.duration, 5, 0.5, 30), w = Math.round(num(a.width, 480, 120, 1280));
        return encode(c, f, { tag: '_clip', ext: '.gif', pre: ['-ss', String(num(a.start, 0, 0, 1e6)), '-t', String(d)], label: 'Making GIF', dur: d,
          args: ['-an', '-vf', `fps=12,scale=${w}:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse`] });
      } },
    transcribe_audio: { d: 'Transcribe speech/lyrics from audio or video with Whisper (via Groq). Works for any length. Returns text + word timestamps and saves .srt and .txt files.', p: { file_id: 'string', language: 'string (optional ISO code)' }, run: transcribe },
    analyze_video: { d: 'Let Gemini actually watch/listen to a video or audio clip and answer a question about it (scenes, people, on-screen text, mood). Best for clips under a few minutes.', p: { file_id: 'string', question: 'string (optional)' }, run: analyze },
    write_text_file: { d: 'Create a downloadable text-based file (txt, srt, csv, md, html) with given content.', p: { name: 'string', content: 'string' },
      async run(a, c) { const o = outPath(String(a.name)); return done(c, o, new Blob([String(a.content)])); } },
  };

  const toolDefs = Object.entries(TOOLS).map(([n, t]) => ({ type: 'function', function: { name: n, description: t.d, parameters: { type: 'object',
    properties: Object.fromEntries(Object.entries(t.p).map(([k, v]) => [k, { type: v.startsWith('number') ? 'number' : 'string', description: v }])),
    required: Object.entries(t.p).filter(([, v]) => !v.includes('optional')).map(([k]) => k) } } }));

  // ---- waveform / filmstrip for the visual trimmer (12 quick seeks instead of decoding the whole video) ----
  async function wavePic(f, film, sig) {
    if (film) {
      const info = await probe(f, sig), n = 12, d = Math.max(1, info.duration);
      const steps = [];
      for (let k = 0; k < n; k++) steps.push(['-ss', ((k + 0.5) * d / n).toFixed(2), '-i', IN(0, f), '-frames:v', '1', '-vf', 'scale=128:-2', W + 'f' + String(k).padStart(2, '0') + '.jpg']);
      steps.push(['-framerate', '1', '-i', W + 'f%02d.jpg', '-vf', `tile=${n}x1`, '-frames:v', '1', W + 'film.jpg']);
      return (await E.run({ inputs: [f], steps, outputs: ['film.jpg'], sig })).outputs['film.jpg'];
    }
    return (await E.run({ inputs: [f], outputs: ['wave.png'], sig,
      args: ['-i', IN(0, f), '-filter_complex', 'showwavespic=s=1200x96:colors=#7c6cff|#22d3ee', '-frames:v', '1', W + 'wave.png'] })).outputs['wave.png'];
  }

  window.StudioTools = { TOOLS, toolDefs, http, wavePic };
})();
