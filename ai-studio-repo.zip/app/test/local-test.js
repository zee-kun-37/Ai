'use strict';
// Runs the REAL in-app code (store/engine/tools/jobs/api) in Node. Only the ffmpeg.wasm backend and
// IndexedDB are replaced: ffmpeg = system CLI, IndexedDB = tiny in-memory fake. Needs `ffmpeg` on PATH.
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const { spawn, spawnSync } = require('child_process');
const L = path.join(__dirname, '..', 'www', 'local');

// ---- browser shims ----
globalThis.window = globalThis;
globalThis.document = { baseURI: 'http://localhost/', addEventListener() {} };
const ls = {}; globalThis.localStorage = { getItem: k => ls[k] ?? null, setItem: (k, v) => { ls[k] = String(v); } };
function fakeIDB() {
  const stores = {};
  const mkReq = fn => { const r = {}; setTimeout(() => { try { r.result = fn(); r.onsuccess && r.onsuccess(); } catch (e) { r.error = e; r.onerror && r.onerror(); } }); return r; };
  const db = { createObjectStore(n, o) { stores[n] = { kp: o && o.keyPath, m: new Map() }; },
    transaction(names) {
      const t = {}; let pending = 0;
      const fin = () => setTimeout(() => t.oncomplete && t.oncomplete(), 5);
      t.objectStore = n => { const s = stores[n]; return {
        put(v, k) { s.m.set(s.kp ? v[s.kp] : k, v); fin(); return {}; }, delete(k) { s.m.delete(k); fin(); return {}; },
        get: k => mkReq(() => s.m.get(k)), getAll: () => mkReq(() => [...s.m.values()]),
        openCursor() { const keys = [...s.m.keys()]; let i = 0; const r = {}; const step = () => setTimeout(() => { r.result = i < keys.length ? { key: keys[i], value: s.m.get(keys[i]), continue() { i++; step(); } } : null; r.onsuccess(); }); step(); return r; } }; };
      return t;
    } };
  return { open() { const r = {}; setTimeout(() => { r.result = db; r.onupgradeneeded && r.onupgradeneeded(); r.onsuccess(); }); return r; } };
}
globalThis.indexedDB = fakeIDB();

// ---- ffmpeg backend = system CLI (same interface as the wasm backend) ----
const R = fs.mkdtempSync(path.join(os.tmpdir(), 'studio-it-'));
const map = s => String(s).replace(/(^|[='\s])\/w(\/|$)/g, (m, a, b) => a + R + '/w' + b).replace(/\/fonts/g, R + '/fonts').replace(/\/in(\d)\//g, R + '/in$1/');
let logCb = null, child = null;
const cli = {
  async available() { return true; }, async load() {}, setLog(cb) { logCb = cb; },
  exec: args => new Promise(res => { const p = child = spawn('ffmpeg', args.map(map)); let b = '';
    p.stderr.on('data', d => { b += d; let m; while ((m = /[\r\n]/.exec(b))) { const l = b.slice(0, m.index); b = b.slice(m.index + 1); if (l && logCb) logCb(l); } });
    p.on('close', c => { if (b && logCb) logCb(b); res(c); }); }),
  async mkdir(p) { fs.mkdirSync(map(p), { recursive: true }); }, async rmdir(p) { fs.rmSync(map(p), { recursive: true, force: true }); },
  async write(p, d) { fs.writeFileSync(map(p), typeof d === 'string' ? d : Buffer.from(d)); }, async read(p) { return fs.readFileSync(map(p)); },
  async list(p) { return fs.readdirSync(map(p)); }, async rm(p) { fs.rmSync(map(p), { force: true }); },
  async mount(i, f) { fs.mkdirSync(`${R}/in${i}`, { recursive: true }); fs.writeFileSync(`${R}/in${i}/${f.name}`, Buffer.from(await f.blob.arrayBuffer())); },
  async unmount(i) { fs.rmSync(`${R}/in${i}`, { recursive: true, force: true }); }, terminate() { if (child) child.kill('SIGKILL'); }, // like worker.terminate()
};

// serve local/font.ttf like the WebView would
const TTF = spawnSync('sh', ['-c', "fc-list : file | grep -i '\\.ttf' | head -1 | sed 's/: *$//'"]).stdout.toString().trim();
const realFetch = globalThis.fetch;
globalThis.fetch = (u, o) => /local\/font\.ttf$/.test(String(u)) && TTF ? Promise.resolve(new Response(fs.readFileSync(TTF))) : realFetch(u, o);
for (const f of ['store', 'engine', 'tools', 'jobs', 'ai', 'api']) require(path.join(L, f + '.js'));
window.StudioEngine._setBackend(cli);
const S = window.StudioStore, E = window.StudioEngine, T = window.StudioTools;

const ok = n => console.log('  ok  ' + n);
async function runTool(name, args) { // through the real /api/tool route + NDJSON stream, like app.js does
  const r = await fetch('/api/tool', { method: 'POST', body: JSON.stringify({ name, args }) });
  const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '', last = null, progs = 0;
  for (;;) { const { done, value } = await rd.read(); if (done) break; buf += dec.decode(value, { stream: true }); }
  for (const l of buf.split('\n').filter(Boolean)) { const ev = JSON.parse(l); if (ev.t === 'prog') progs++; last = ev; }
  return { ...last, progs };
}
const dur = async id => (await E.probe(S.need(id))).duration;

(async () => {
  assert.equal(await (await fetch('/api/health')).json().then(j => j.ffmpeg), true); ok('health');
  // source clip: 4s video+audio, then 2s of silence appended so remove_silence has work
  const src = path.join(R, 'src.mp4');
  assert.equal(spawnSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=15:duration=6', '-f', 'lavfi', '-i', "aevalsrc='if(lt(t,3),sin(440*2*PI*t),0)':d=6:s=44100", '-shortest', '-pix_fmt', 'yuv420p', src]).status, 0);
  const id = 'aaaaaaaa'; await S.put(id, 'src.mp4', new Blob([fs.readFileSync(src)]), null);
  assert.equal((await (await fetch('/api/files')).json()).length, 1); ok('upload/list');

  const p = await E.probe(S.need(id));
  const ref = JSON.parse(spawnSync('ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', src]).stdout);
  assert.ok(Math.abs(p.duration - +ref.format.duration) < 0.05 && p.hasVideo && p.hasAudio && p.w === 320 && p.h === 240);
  assert.equal(p.streams.find(s => s.type === 'video').codec, 'h264'); ok('probe matches ffprobe (' + p.duration + 's ' + p.w + 'x' + p.h + ')');

  let r = await runTool('trim_media', { file_id: id, start: 1, end: 3 });
  assert.equal(r.t, 'done', r.error); assert.ok(Math.abs(await dur(r.result.id) - 2) < 0.3); assert.equal(S.need(r.result.id).parent, id); ok('trim (+ progress events: ' + r.progs + ', lineage)');
  const tr = r.result.id;
  r = await runTool('change_speed', { file_id: id, speed: 2 }); assert.equal(r.t, 'done', r.error); assert.ok(Math.abs(await dur(r.result.id) - 3) < 0.3); ok('change_speed');
  r = await runTool('crop_video', { file_id: id, preset: 'vertical_9x16' }); assert.equal(r.t, 'done', r.error); let i = await E.probe(S.need(r.result.id)); assert.equal(i.w, 1080); assert.equal(i.h, 1920); ok('crop 9:16');
  r = await runTool('remove_silence', { file_id: id }); assert.equal(r.t, 'done', r.error); assert.ok(r.result.removed_seconds > 2, JSON.stringify(r.result)); ok('remove_silence (removed ' + r.result.removed_seconds + 's)');
  r = await runTool('make_gif', { file_id: id, start: 0, duration: 1 }); assert.equal(r.t, 'done', r.error); assert.match(r.result.name, /\.gif$/); ok('make_gif');
  r = await runTool('extract_frame', { file_id: id, time: 1 }); assert.equal(r.t, 'done', r.error); ok('extract_frame');
  r = await runTool('merge_media', { file_ids: id + ',' + tr }); assert.equal(r.t, 'done', r.error); assert.ok(await dur(r.result.id) > 7.5); ok('merge');
  r = await runTool('compress_video', { file_id: id, quality: 'low' }); assert.equal(r.t, 'done', r.error); ok('compress');
  r = await runTool('resize_video', { file_id: id, height: 120 }); assert.equal(r.t, 'done', r.error); assert.equal((await E.probe(S.need(r.result.id))).h, 120); ok('resize');
  r = await runTool('normalize_audio', { file_id: id }); assert.equal(r.t, 'done', r.error); ok('normalize_audio (video, -c:v copy)');
  r = await runTool('convert_media', { file_id: id, format: 'mp3' }); assert.equal(r.t, 'done', r.error); const mp3 = r.result.id; assert.ok(Math.abs(await dur(mp3) - 6) < 0.3); ok('convert -> mp3');
  r = await runTool('convert_media', { file_id: id, format: 'webm' }); assert.equal(r.t, 'done', r.error); ok('convert -> webm');
  r = await runTool('trim_media', { file_id: mp3, start: 0, end: 2 }); assert.equal(r.t, 'done', r.error); ok('trim on audio-only (no x264 flags leak)');
  r = await runTool('change_speed', { file_id: mp3, speed: 1.5 }); assert.equal(r.t, 'done', r.error); ok('speed on audio-only');
  r = await runTool('remove_silence', { file_id: mp3 }); assert.equal(r.t, 'done', r.error); ok('remove_silence on audio-only');
  const srt = (await runTool('write_text_file', { name: 's.srt', content: '1\n00:00:00,000 --> 00:00:02,000\nHello\n' })).result.id;
  r = await runTool('burn_subtitles', { file_id: id, srt_file_id: srt }); assert.equal(r.t, 'done', r.error); ok('burn_subtitles');
  r = await runTool('probe_media', { file_id: id }); assert.equal(r.t, 'done'); assert.ok(r.result.streams.length === 2); ok('probe_media');
  assert.ok((await T.wavePic(S.need(id), false)).size > 500); assert.ok((await T.wavePic(S.need(id), true)).size > 500); ok('waveform + filmstrip');
  const t = await (await fetch('/api/text/' + srt)).json(); assert.match(t.text, /Hello/);
  const sv = await (await fetch('/api/savetext', { method: 'POST', body: JSON.stringify({ name: 'e.srt', text: 'x', parent: srt }) })).json(); assert.equal(sv.parent, srt); ok('text edit -> new version');
  r = await runTool('trim_media', { file_id: id, start: 5, end: 1 }); assert.equal(r.t, 'error'); assert.match(r.error, /greater/); ok('error reporting');
  r = await runTool('trim_media', { file_id: 'zzzzzzzz', start: 0, end: 1 }); assert.equal(r.t, 'error'); ok('unknown file id');
  // cancel: queue a job and stop it immediately
  const resp = await fetch('/api/tool', { method: 'POST', body: JSON.stringify({ name: 'compress_video', args: { file_id: id } }) });
  const jobs = await (await fetch('/api/jobs')).json(); const run = jobs.jobs.find(j => j.status === 'running');
  assert.ok(run); assert.equal((await (await fetch('/api/jobs/' + run.id + '/stop', { method: 'POST' })).json()).ok, true);
  await resp.text(); assert.equal((await (await fetch('/api/jobs')).json()).jobs.find(j => j.id === run.id).status, 'cancelled'); ok('stop job');
  const n = (await (await fetch('/api/files')).json()).length; assert.equal((await (await fetch('/api/file/' + tr, { method: 'DELETE' })).json()).ok, true);
  assert.equal((await (await fetch('/api/files')).json()).length, n - 1); ok('delete');
  // pure helpers still match the server's unit tests
  assert.equal(S.srtTime(3661.5), '01:01:01,500'); assert.equal(S.atempoChain(4), 'atempo=2,atempo=2.0000'); assert.equal(S.safeName('../../etc/pa$$wd.mp4'), 'pa__wd.mp4');
  assert.deepEqual(S.cropBox(1920, 1080, 9, 16), { cw: 608, ch: 1080 }); assert.equal(T.toolDefs.length, 16); ok('helpers + 16 tool defs');
  console.log('\nALL PASSED'); process.exit(0);
})().catch(e => { console.error('\nFAILED:', e); process.exit(1); });
